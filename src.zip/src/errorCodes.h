#ifndef ERROR_CODES_H
#define ERROR_CODES_H

#define RESULT_OK 0
#define RESULT_FAIL -1
#define PERSON_TOO_FAST -2
//#define SENSOR_TIMEOUT_ERROR -3

#endif
